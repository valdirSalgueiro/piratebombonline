export default function createRotatingPlatform(scene, x, y, numTiles = 5) {}
