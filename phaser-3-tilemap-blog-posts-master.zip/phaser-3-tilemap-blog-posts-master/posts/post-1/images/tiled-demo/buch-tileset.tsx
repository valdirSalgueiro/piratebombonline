<?xml version="1.0" encoding="UTF-8"?>
<tileset name="buch-tileset" tilewidth="48" tileheight="48" tilecount="247" columns="19">
 <grid orientation="orthogonal" width="16" height="16"/>
 <image source="buch-tileset-3x.png" width="912" height="624"/>
</tileset>
